"""
Copyright (c) 2018 ark1ee <onlyarter@gmail.com>
"""

from .musing import Musing, MusingRhythm, Clip
from .musthe import Note, Interval, Chord, scale
m_ryhthm = MusingRhythm()